package main;

import entities.Estudiante;

public interface Prueba {
    void calcularNotaAlumno(Estudiante est, int nota1, int nota2);
}
